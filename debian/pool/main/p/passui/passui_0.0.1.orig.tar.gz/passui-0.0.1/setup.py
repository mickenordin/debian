import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="passui",
    version="0.0.1",
    author="Micke Nordin",
    author_email="hej@mic.ke",
    data_files = [('share/applications', ['data/org.smolnet.passui.desktop']),],
    description="A GUI for the standad Unix password manager.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://code.smolnet.org/micke/passui",
    project_urls={
        "Bug Tracker": "https://code.smolnet.org/micke/passui",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GPL-3.0",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.9",
    scripts=["scripts/passui"],
)
