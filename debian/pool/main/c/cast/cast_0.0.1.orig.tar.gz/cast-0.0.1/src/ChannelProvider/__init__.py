#/usr/bin/env python3
import threading
import time
from os import path

import wx

from Channel import Channel
from Utils import get_default_logo, get_latest

MYPATH = path.dirname(path.abspath(__file__))


class ChannelProvider:
    def __init__(self, providerid: str, channels:list[Channel]):
        self.m_id = providerid
        self.m_logo: wx.Bitmap = get_default_logo(providerid)
        self.m_channels: list[Channel] = channels
        if len(self.m_channels) > 0 and not providerid == 'SVT':
            self.m_thr = threading.Thread(target=self.make_latest,
                                          args=(),
                                          kwargs={})
            self.m_thr.start()

    def append_channel(self, channel: Channel) -> int:
        self.m_channels.append(channel)
        return len(self.m_channels)

    def get_channels(self) -> list[Channel]:
        return self.m_channels

    def get_channel_by_index(self, channel_index: int) -> Channel:
        return self.m_channels[channel_index]

    def get_logo_as_bitmap(self) -> wx.Bitmap:
        return self.m_logo

    def get_name(self) -> str:
        return self.m_id

    def make_latest(self) -> None:
        items = get_latest(self.m_id)
        channel_id = self.m_id + "_latest"
        channel = Channel(channel_id, self.get_name(), '', self.m_logo,
                          "Latest videos")
        channel.set_items(items)
        self.prepend_channel(channel)

    def prepend_channel(self, channel: Channel) -> int:
        self.m_channels.insert(0, channel)
        return len(self.m_channels)

    def set_channels(self, channels: list[Channel]) -> None:
        self.m_channels = channels
