# cast

This program is intended for use on linux phones, and allow watching video streams, either directly on the phone via gstreamer or through chrome cast.

Currently Swedish Public Service TV is supported.
