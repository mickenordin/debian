import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="cast",
    version="0.0.1",
    author="Micke Nordin",
    author_email="hej@mic.ke",
    data_files=[('share/applications', ['data/org.smolnet.cast.desktop']),
                ('share/cast/assets', [
                    'data/assets/Barnkanalen.png', 'data/assets/Cast.png',
                    'data/assets/Default.png',
                    'data/assets/Kunskapskanalen.png', 'data/assets/SVT1.png',
                    'data/assets/SVT24.png', 'data/assets/SVT2.png',
                    'data/assets/SVT.png', 'data/assets/YouTube.png'
                ])],
    description="A Public Service video player.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://code.smolnet.org/micke/cast",
    project_urls={
        "Bug Tracker": "https://code.smolnet.org/micke/cast/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GPL-3.0",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.9",
    scripts=["scripts/cast"],
)
