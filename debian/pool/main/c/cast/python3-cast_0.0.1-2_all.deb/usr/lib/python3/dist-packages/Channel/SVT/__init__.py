#!/usr/bin/env python3

import json
from datetime import datetime

import feedparser
import requests
import wx
from bs4 import BeautifulSoup

from Channel import Channel
from Items import Item
from Utils import (add_video, hash_string, make_bitmap_from_url,
                   resolve_svt_channel, video_exists)

default_rss_url = 'http://www.svtplay.se/rss.xml'


class SVT(Channel):
    def __init__(self, channel_id: str) -> None:
        chan_dict = resolve_svt_channel(channel_id)
        logo = chan_dict['thumbnail']
        name = chan_dict['name']
        super().__init__(channel_id, 'SVT', default_rss_url, logo, name)

    def parse_feed(self) -> None:
        #self.m_items: list[Item] = list()
        resolved_link = str()
        description = str()
        title = str()
        thumbnail_link = str()
        thumbnail: wx.Bitmap = wx.Bitmap()
        published_parsed: datetime = datetime.now()
        video_id = str()

        if self.m_id == 'feed' :
            feed = feedparser.parse(self.get_feed())
            entries = feed['entries']
            for entry in entries:
                video_id = hash_string(entry['id'])
                svt_id = str()
                if video_exists(video_id, 'feed'):
                    continue
                for link in entry['links']:
                    if str(link['type']).startswith('image/'):
                        thumbnail_link = str(link['href'])

                        break
                page = requests.get(str(entry['link']))
                soup = BeautifulSoup(page.text, 'html.parser')

                for element in soup.find_all('a'):
                    href = element.get('href')
                    datart = element.get('data-rt')

                    if datart == 'top-area-play-button':
                        svt_id = href.split('=')[1].split('&')[0]

                resolved_link = self.resolve_link(svt_id)
                description = str(entry['description'])
                published_parsed = entry['published_parsed']
                title = str(entry['title'])
                if not resolved_link:
                    continue
                thumbnail = make_bitmap_from_url(
                    thumbnail_link, wx.Size(int(self.m_screen_width), 150))
                item = Item(description, resolved_link, self.m_provider_name,
                            published_parsed, thumbnail, title)
                self.m_items.append(item)
                add_video(video_id, self.m_id, self.m_provider_name, description,
                          resolved_link, published_parsed, thumbnail, title, 0)

        else:
            chan_dict = resolve_svt_channel(self.m_id)
            resolved_link = self.resolve_link(self.m_id)
            video_id = hash_string(resolved_link)
            title = chan_dict['name']
            description = "Live channel stream"
            thumbnail = chan_dict['thumbnail']

            if resolved_link:
                item = Item(description, resolved_link, self.m_provider_name,
                            published_parsed, thumbnail, title)
                self.m_items.append(item)


    def resolve_link(self,svt_id) -> str:
        url = 'https://api.svt.se/video/{}'.format(svt_id)
        print(url)
        api = json.loads(
            requests.get(url).text)
        resolved_link = ''

        try:
            for reference in api['videoReferences']:
                if reference['format'] == "dashhbbtv":
                    resolved_link = reference['url']
        except KeyError:
            pass
        return resolved_link

