#!/usr/bin/env python3
from datetime import datetime

import wx


class Item(dict):
    def __init__(self,
                 description: str,
                 link: str,
                 provider_id: str,
                 published: datetime,
                 thumbnail: wx.Bitmap,
                 title: str,
                 watchtime: int = 0):
        self.__dict__['description'] = description
        self.__dict__['link'] = link
        self.__dict__['provider_id'] = provider_id
        self.__dict__['published'] = published
        self.__dict__['thumbnail'] = thumbnail
        self.__dict__['title'] = title
        self.__dict__['watchtime'] = watchtime

    def __setitem__(self, key, item):
        self.__dict__[key] = item

    def __getitem__(self, key):
        return self.__dict__[key]

    def __repr__(self):
        return repr(self.__dict__)

    def __delitem__(self, key):
        del self.__dict__[key]

    def clear(self):
        return self.__dict__.clear()

    def copy(self):
        return self.__dict__.copy()

    def has_key(self, k):
        return k in self.__dict__

    def update(self, *args, **kwargs):
        return self.__dict__.update(*args, **kwargs)

    def keys(self):
        return self.__dict__.keys()

    def values(self):
        return self.__dict__.values()

    def items(self):
        return self.__dict__.items()

    def pop(self, *args):
        return self.__dict__.pop(*args)

    def __cmp__(self, dict_):
        return self.__dict__ == dict_

    def __contains__(self, item):
        return item in self.__dict__

    def __iter__(self):
        return iter(self.__dict__)
