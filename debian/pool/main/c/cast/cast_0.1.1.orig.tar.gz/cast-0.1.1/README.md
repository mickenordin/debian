# cast

This program is intended for use on linux phones, and allow watching video streams, either directly on the phone via vlc or through chromecast.

Currently Swedish Public Service TV is supported.

Install like this:

```
wget -O - https://repo.mic.ke/PUBLIC.KEY | gpg --dearmor --output micke-archive-unstable.gpg && sudo mv micke-archive-unstable.gpg /usr/share/keyrings
sudo wget -O /etc/apt/sources.list.d/debian-micke-unstable.list   https://repo.mic.ke/debian/debian-micke-unstable.list
sudo apt update && sudo apt install cast
```
    
