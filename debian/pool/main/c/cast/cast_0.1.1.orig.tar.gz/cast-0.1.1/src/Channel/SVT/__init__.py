#!/usr/bin/env python3

import json
from datetime import datetime

import feedparser
import requests
import wx

from Channel import Channel
from Items import Item
from Utils import (add_video, get_all_svt_categories, get_all_svt_programs,
                   get_svt_category, get_svt_id, get_svt_thumb_from_id_changed,
                   get_svt_thumbnail, hash_string, make_bitmap_from_url,
                   resolve_svt_channel, video_exists)

default_rss_url = 'http://www.svtplay.se/rss.xml'


class SVT(Channel):

    def __init__(self, channel_id: str) -> None:
        chan_dict = resolve_svt_channel(channel_id)
        logo = chan_dict['thumbnail']
        name = chan_dict['name']
        super().__init__(channel_id, 'SVT', default_rss_url, logo, name)

    def parse_feed(self) -> None:
        resolved_link = str()
        description = str()
        title = str()
        thumbnail_link = str()
        thumbnail: wx.Bitmap = wx.Bitmap()
        published_parsed: datetime = datetime.now()
        video_id = str()
        categories: dict = dict()
        for category in get_all_svt_categories():
            categories[category['id']] = category

        if self.m_id == 'feed':
            feed = feedparser.parse(self.get_feed())
            entries = feed['entries']
            for entry in entries:
                video_id = hash_string(entry['id'])
                svt_id = str()
                if video_exists(video_id, 'feed'):
                    continue
                for link in entry['links']:
                    if str(link['type']).startswith('image/'):
                        thumbnail_link = str(link['href'])

                        break
                svt_id = get_svt_id(str(entry['link']))
                resolved_link = self.resolve_link(svt_id)
                description = str(entry['description'])
                published_parsed = entry['published_parsed']
                title = str(entry['title'])
                if not resolved_link:
                    continue
                thumbnail = make_bitmap_from_url(
                    thumbnail_link, wx.Size(int(self.m_screen_width), 150), video_id)
                item = Item(description, resolved_link, self.m_provider_name,
                            published_parsed, thumbnail, title)
                self.m_items.append(item)
                add_video(video_id, self.m_id, self.m_provider_name,
                          description, resolved_link, published_parsed,
                          thumbnail, title, 0)

        elif self.m_id == 'allprograms':
            entries = get_all_svt_programs()
            for entry in entries:
                url = entry['item']['urls']['svtplay']
                video_id = hash_string(url.split('/')[1])
                svt_id = str()
                link = "https://svtplay.se{}".format(url)
                if video_exists(video_id, 'allprograms'):
                    continue
                thumbnail_link = get_svt_thumbnail(link)

                svt_id = get_svt_id(link)
                resolved_link = self.resolve_link(svt_id)
                title = str(entry['heading'])
                type = str(entry['item']['__typename'])
                published_parsed = datetime.now()
                swe_only = "no"
                if entry['item']['restrictions']['onlyAvailableInSweden']:
                    swe_only = 'yes'
                description = "{}\nOnly available in Sweden:{}\nType of program:{}".format(
                    title, swe_only, type)
                if not resolved_link:
                    continue
                thumbnail = make_bitmap_from_url(
                    thumbnail_link, wx.Size(int(self.m_screen_width), 150), video_id)
                item = Item(description,
                            resolved_link,
                            self.m_provider_name,
                            published_parsed,
                            thumbnail,
                            title,
                            sort_key=entry['selection_name'])
                self.m_items.append(item)
                add_video(video_id, self.m_id, self.m_provider_name,
                          description, resolved_link, published_parsed,
                          thumbnail, title, 0)
        elif self.m_id in categories.keys():
            entries = get_svt_category(self.m_id)
            for entry in entries:
                elem = entry["item"]
                imgformat = "wide"
                if not "wide" in elem["images"].keys():
                    if "cleanWide" in elem["images"].keys():
                        imgformat = "cleanWide"
                    else:
                        continue
                url = elem["urls"]["svtplay"]
                video_id = hash_string(url)
                svt_id = elem["videoSvtId"]
                resolved_link = self.resolve_link(svt_id)
                if not resolved_link:
                    continue
                title = str(entry['heading'])
                description = str(entry["description"])
                published_parsed = datetime.now()
                thumbnail_link = get_svt_thumb_from_id_changed(
                    elem['images'][imgformat]["id"],
                    elem['images'][imgformat]["changed"],
                    size=self.m_screen_width)
                thumbnail = make_bitmap_from_url(
                    thumbnail_link, wx.Size(int(self.m_screen_width), 150), video_id)
                item = Item(description, resolved_link, self.m_provider_name,
                            published_parsed, thumbnail, title)
                self.m_items.append(item)
                add_video(video_id, self.m_id, self.m_provider_name,
                          description, resolved_link, published_parsed,
                          thumbnail, title, 0)

        else:
            chan_dict = resolve_svt_channel(self.m_id)
            resolved_link = self.resolve_link(self.m_id)
            video_id = hash_string(resolved_link)
            title = chan_dict['name']
            description = "Live channel stream"
            thumbnail = chan_dict['thumbnail']

            if resolved_link:
                item = Item(description, resolved_link, self.m_provider_name,
                            published_parsed, thumbnail, title)
                self.m_items.append(item)

    def resolve_link(self, svt_id) -> str:
        url = 'https://api.svt.se/video/{}'.format(svt_id)
        print(url)
        api = json.loads(requests.get(url).text)
        resolved_link = ''

        try:
            for reference in api['videoReferences']:
                if reference['format'] == "dashhbbtv":
                    resolved_link = reference['url']
        except KeyError:
            pass
        return resolved_link
