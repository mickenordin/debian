#!/usr/bin/env python3

from typing import Union

import wx
import threading

from Items import Item
from Utils import get_videos


class Channel:
    def __init__(self,
                 channel_id: str,
                 provider_name: str,
                 feed: str,
                 logo: wx.Bitmap,
                 name: str) -> None:
        self.m_id = channel_id
        self.m_logo = logo
        self.m_provider_name = provider_name
        self.m_name = name
        self.m_feed = feed
        self.m_items: list[Item] = get_videos(channel_id)
        self.m_screen_width = (720/2)
        if len(self.m_items) < 1:
            self.refresh()

    def get_logo_as_bitmap(self) -> wx.Bitmap:
        return self.m_logo

    def get_feed(self) -> str:
        return self.m_feed

    def get_items(self) -> Union[list[Item], None]:
        return self.m_items

    def get_id(self) -> str:
        return self.m_id

    def get_latest_item(self) -> Item:
        return self.m_items[0] # type: ignore

    def get_name(self) -> str:
        return self.m_name

    def get_provider_name(self) -> str:
        return self.m_provider_name

    def parse_feed(self) -> Union[list[Item], None]:
        return None

    def refresh(self) -> None:
        if self.wait():
            return
        self.m_thr = threading.Thread(target=self.parse_feed,
                                      args=(),
                                      kwargs={})
        self.m_thr.start()

    def set_items(self, items: list[Item]) -> None:
        self.m_items = items

    def set_logo(self, logo: wx.Bitmap) -> None:
        self.m_logo = logo

    def wait(self) -> bool:
        result = False
        try:
            result = self.m_thr.is_alive()
        except AttributeError:
            pass
        return result

