#!/usr/bin/env python3
# -*- coding: utf-8 -*-


class UserOrError:
    """Class that can be either a username or an error message from the bridge
    """

    def __init__(self):
        """Constructor
        """
        self.UNKNOWNERROR = 9999
        self.muser: str = str()
        self.merror: bool = True
        self.mcode: int = self.UNKNOWNERROR

    def get_error_code(self) -> int:
        """Thhis is an error code if this an error

        Returns:
            int: error code from Hue API
        """
        return self.mcode

    def get_user(self) -> str:
        """Get the username

        Returns:
            str: the username we stored
        """
        return self.muser

    def is_error(self) -> bool:
        """Check if this is an error

        Returns:
            bool: True if ther is an error or False otherwise
        """
        return self.merror

    def set_error(self, code: int):
        """Set an error code

        Args:
            code (int): An error code to set
        """
        self.merror = True
        self.mcode = code

    def set_user(self, username: str):
        """Set the username

        Args:
            username (str): Username to set
        """
        self.merror = False
        self.muser = username
