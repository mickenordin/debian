# tinge

Tinge is a mobile first application for controlling Philips Hue lights on Linux

## Installation
Install wxPython (don't use pip to install it) eg. for PostmarketOS: 
```
sudo apk add py3-wxpython
```
or for Debian/Mobian:
```
sudo apt install python3-wxgtk4.0
```

clone this repository:
```
git clone https://code.smolnet.org/micke/tinge
```
Run the crude installer:
```
cd tinge
./install.sh
```
## Requirements
Requires a recent Python3 and pip3, most likely python >= 3.7. It is only tested with 3.9 on PostmarketOS on the PinePhone and on Debian Bullseye though.

## Future plans
Check out the [Roadmap](https://code.smolnet.org/micke/tinge/src/branch/master/Roadmap.md)

## Help
If you find any bugs (that is broken, existing features) please open an issue here. You are also welcome to open an issue with requests for new features (check existing issues first as to avoid duplicates).

You can also join #tinge on irc.libera.chat or use the [kiwiirc webchat](https://kiwiirc.com/nextclient/irc.libera.chat/#tinge) to ask any questions.

## Donations
[![Donate using Liberapay](https://liberapay.com/assets/widgets/donate.svg)](https://liberapay.com/micke/donate)

If you want, you can chip in for server costs on [Liberapay](https://liberapay.com/micke/donate).

## Screenshots
![Discover Bridge View](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot1.png)
![All Bridge View](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot2.png)
![All Group View](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot3.png)
![Single Group View, with Some Lights Off, and Roof light unreachable](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot4.png)
![Single Light View, with Bed Lamp Off](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot5.png)
![Single Light View, with Bed Lamp On](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot6.png)
![Single Group View, with Bed Lamp On](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot7.png)
![Rename Bed lamp](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot8.png)
![Single Light View, with Bed Lamp renamed to Table lamp](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot9.png)
![Single Group View, with Bed Lamp renamed to Table lamp](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot10.png)
![Single Light View, with Table lamp Delete modal](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot11.png)
![Single Group View, with Table lamp Deleted](https://code.smolnet.org/micke/tinge/raw/branch/master/screenshots/scrot12.png)
